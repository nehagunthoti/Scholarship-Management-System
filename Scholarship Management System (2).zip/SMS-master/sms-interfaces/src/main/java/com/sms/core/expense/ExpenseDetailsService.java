package com.sms.core.expense;

/**
 * Created by sathish on 10/4/2016.
 */
interface ExpenseDetailsService {
    /**
     *
     * @param id
     */
    void deleteExpenseDetails(final long id);

}
