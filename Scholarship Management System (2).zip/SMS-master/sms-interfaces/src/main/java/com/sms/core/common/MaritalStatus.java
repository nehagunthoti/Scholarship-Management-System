package com.sms.core.common;

public enum MaritalStatus {

    MARRIED, SINGLE;
}
