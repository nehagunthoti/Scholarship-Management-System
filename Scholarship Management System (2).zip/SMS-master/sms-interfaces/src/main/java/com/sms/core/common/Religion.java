package com.sms.core.common;

public enum Religion {

    HINDU, MUSLIM, CHRISTIAN, SIKH, PARSI, JAIN, BUDDHIST, OTHERS;
}
