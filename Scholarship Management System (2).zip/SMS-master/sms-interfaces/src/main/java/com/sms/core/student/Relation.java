package com.sms.core.student;

public enum Relation {

    FATHER, MOTHER, BROTHER, SISTER;
}
