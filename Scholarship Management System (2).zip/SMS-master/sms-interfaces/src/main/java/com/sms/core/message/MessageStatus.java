package com.sms.core.message;

/**
 * Created by sathish on 7/15/2016.
 */
public enum MessageStatus
{
    SENT,RECEIVED;
}
