package com.sms.core.identity;

/**
 * Created by Ganesan on 28/06/16.
 */
public enum IdCardStatus {

    REQUESTED,
    PRINTED,
    TRANSPORTED,
    RECEIVED,
    MISSED

}
