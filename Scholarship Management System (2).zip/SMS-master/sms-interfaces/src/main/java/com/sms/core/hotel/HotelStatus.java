package com.sms.core.hotel;

/**
 * Created by sathish on 7/14/2016.
 */
public enum HotelStatus
{
    CREATED, DELETED ;
}
