package com.sms.core.student;

/**
 * Created by Ram on 6/20/2016.
 */
public enum LanguageLevel {
    READ, WRITE, SPEAK;
}
