package com.sms.core.attendance;

/**
 * Created by Assaycr-04 on 8/22/2016.
 */
public enum AttendanceStatus {
    PRESENT,ABSENT,LEAVE,HOLIDAY
}
