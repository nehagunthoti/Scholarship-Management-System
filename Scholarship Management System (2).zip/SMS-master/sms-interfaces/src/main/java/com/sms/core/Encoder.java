package com.sms.core;

public interface Encoder {

	String encode(final String data);
}
