package com.sms.core.repositery;

import com.sms.core.admin.RoleOperationLink;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by Ganesan on 25/05/16.
 */
public interface RoleOperationLinkRepository extends JpaRepository<RoleOperationLink, Long> {

}
