package com.sms.core.common;

public enum Gender {

    MALE, FEMALE, OTHERS;
}
