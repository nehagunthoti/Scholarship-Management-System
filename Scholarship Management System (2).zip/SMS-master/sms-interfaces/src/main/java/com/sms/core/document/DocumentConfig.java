package com.sms.core.document;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * Created by Ganesan on 20/06/16.
 */
//@Configuration
//@ComponentScan(basePackages = "com.sms.core")
public class DocumentConfig {

//    @Autowired private ApplicationContext ctx;

//    @Bean
//    public Map<String, DocumentCallBack> documentCallBacks(){
//        return ctx.getBeansOfType( DocumentCallBack.class );
//    }
}
