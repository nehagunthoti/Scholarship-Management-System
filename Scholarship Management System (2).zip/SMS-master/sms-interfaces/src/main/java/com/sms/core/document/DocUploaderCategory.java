package com.sms.core.document;

/**
 * Created by Ganesan on 28/06/16.
 */
public enum DocUploaderCategory {

    STUDENT, TEACHER
}
