package com.sms.core.student;

public enum StudentStatus {

    CREATED, DOC_UPLOADED, ALUMINI, DIS_CONTINUED;
}
