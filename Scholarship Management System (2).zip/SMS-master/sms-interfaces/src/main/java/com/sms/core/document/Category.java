package com.sms.core.document;

/**
 * Created by Ganesan on 06/06/16.
 */
public class Category {

    private Long id;
    private String name;
    private String desc;

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public Long getId() {
        return id;
    }
}
