package com.sms.core.common;

public enum Caste {

    SC, ST, OBC, OC, MBC, BC, OTHERS;
}
