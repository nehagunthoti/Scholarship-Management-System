package com.sms.core.scholarship;

/**
 * Created by sathish on 7/2/2016.
 */
public enum ScholarStatus {
    INSERTED, ENROLLED, EXPIRED
}
