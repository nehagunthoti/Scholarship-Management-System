package com.sms.core.document;

/**
 * Created by Ganesan on 10/06/16.
 */
public class UpdateInfo {

    private String category;
    private String uploaderId;
    private String status;

    public String getCategory() {
        return category;
    }

    public String getUploaderId() {
        return uploaderId;
    }

    public String getStatus() {
        return status;
    }
}
