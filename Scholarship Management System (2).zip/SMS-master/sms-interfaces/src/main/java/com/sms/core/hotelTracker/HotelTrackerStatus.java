package com.sms.core.hotelTracker;

/**
 * Created by sathish on 7/19/2016.
 */
public enum HotelTrackerStatus
{
    MAPPED,SUSPENDED,COMPLETED;
}
