package com.sms.core.payment;

import com.sms.core.repositery.StudentRepository;

/**
 * Created by Ganesan on 25/06/16.
 */
public class PaymentConfig {

    private StudentRepository studentRepository;



}
