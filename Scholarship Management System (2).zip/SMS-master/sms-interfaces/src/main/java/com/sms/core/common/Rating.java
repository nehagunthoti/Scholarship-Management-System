package com.sms.core.common;

public enum Rating {

    EXCELLENT, AVERAGE, BELOW_AVERAGE;
}
