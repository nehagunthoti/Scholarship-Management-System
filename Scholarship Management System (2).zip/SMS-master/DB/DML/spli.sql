INSERT INTO sms_ms_marketing_commission_config(
            id, mcc_sub_ordinate, mcc_superior, amount)
    VALUES (nextval('SMS_SQ_MCC'), 0, 0, 1000);

INSERT INTO sms_ms_marketing_commission_config(
            id, mcc_sub_ordinate, mcc_superior, amount)
    VALUES (nextval('SMS_SQ_MCC'), 1, 0, 700);

INSERT INTO sms_ms_marketing_commission_config(
            id, mcc_sub_ordinate, mcc_superior, amount)
    VALUES (nextval('SMS_SQ_MCC'), 1, 1, 300);

INSERT INTO sms_ms_marketing_commission_config(
            id, mcc_sub_ordinate, mcc_superior, amount)
    VALUES (nextval('SMS_SQ_MCC'), 2, 0, 400);

INSERT INTO sms_ms_marketing_commission_config(
            id, mcc_sub_ordinate, mcc_superior, amount)
    VALUES (nextval('SMS_SQ_MCC'), 2, 1, 300);

INSERT INTO sms_ms_marketing_commission_config(
            id, mcc_sub_ordinate, mcc_superior, amount)
    VALUES (nextval('SMS_SQ_MCC'), 2, 2, 300);
